list.Set( "PlayerOptionsModel", "Css_enhanced_swat", "models/css_seb_swat/css_swat.mdl" )
player_manager.AddValidModel( "Css_enhanced_swat", "models/css_seb_swat/css_swat.mdl" )
player_manager.AddValidHands( "Css_enhanced_swat", "models/css_seb_swat/css_swat_arms.mdl", 0, "00000000" )